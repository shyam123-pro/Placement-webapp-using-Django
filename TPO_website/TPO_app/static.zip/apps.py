from django.apps import AppConfig


class TpoAppConfig(AppConfig):
    name = 'TPO_app'
